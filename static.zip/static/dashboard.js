// static/dashboard.js

// Socket.IO connection
const socket = io();

// Global variables
let currentSymbol = 'AAPL';
let updateInterval = null;

// Connect to WebSocket
socket.on('connect', function() {
    console.log('Connected to server');
    showNotification('Connected to real-time updates', 'success');
});

socket.on('data_updated', function(data) {
    console.log('Data updated:', data);
    refreshCurrentView();
});

socket.on('new_alert', function(alert) {
    console.log('New alert:', alert);
    showNotification(`${alert.symbol}: ${alert.message}`, 'warning');
    updateAlertsList();
});

socket.on('realtime_update', function(data) {
    console.log('Real-time update:', data);
    updateStockPrice(data.symbol, data.price, data.change);
});

// Utility functions
function showNotification(message, type = 'info') {
    // Create toast notification
    const toast = document.createElement('div');
    toast.className = `toast align-items-center text-white bg-${type} border-0`;
    toast.setAttribute('role', 'alert');
    toast.setAttribute('aria-live', 'assertive');
    toast.setAttribute('aria-atomic', 'true');
    
    toast.innerHTML = `
        <div class="d-flex">
            <div class="toast-body">
                ${message}
            </div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
        </div>
    `;
    
    document.body.appendChild(toast);
    const bsToast = new bootstrap.Toast(toast);
    bsToast.show();
    
    // Remove after 5 seconds
    setTimeout(() => toast.remove(), 5000);
}

function showLoading(containerId) {
    const container = document.getElementById(containerId);
    if (container) {
        container.innerHTML = '<div class="spinner"></div>';
    }
}

function formatNumber(num, decimals = 2) {
    return Number(num).toFixed(decimals);
}

function formatPercent(num) {
    return `${(num * 100).toFixed(2)}%`;  // Fixed: removed stray %
}

function updateStockPrice(symbol, price, change) {
    const priceElement = $(`#price-${symbol}`);
    if (priceElement.length) {
        const changeClass = change >= 0 ? 'text-success' : 'text-danger';
        const changeSign = change >= 0 ? '+' : '';
        priceElement.html(`
            $${formatNumber(price)}<br>
            <small class="${changeClass}">${changeSign}${(change * 100).toFixed(2)}%</small>
        `);
        priceElement.addClass('realtime-update');
        setTimeout(() => priceElement.removeClass('realtime-update'), 1000);
    }
}

function refreshCurrentView() {
    const path = window.location.pathname;
    
    if (path === '/dashboard') {
        loadDashboard();
    } else if (path === '/portfolio') {
        loadPortfolio();
    } else if (path === '/monitor') {
        loadMonitor();
    } else if (path === '/ml_insights') {
        loadMLInsights();
    }
}

// Dashboard functions
function loadDashboard() {
    const urlParams = new URLSearchParams(window.location.search);
    const symbol = urlParams.get('symbol') || 'AAPL';
    currentSymbol = symbol;
    
    showLoading('chart-container');
    showLoading('stats-container');
    
    // Load stock data
    $.get(`/api/stock_data/${symbol}`, function(data) {
        if (data.success) {
            // Plot chart
            Plotly.newPlot('chart-container', JSON.parse(data.chart).data, 
                          JSON.parse(data.chart).layout);
            
            // Update stats
            $('#current-price').text(data.stats.price);
            $('#price-change').text(data.stats.change)
                .removeClass('text-success text-danger')
                .addClass(data.stats.change.includes('-') ? 'text-danger' : 'text-success');
            $('#volume').text(data.stats.volume);
            $('#day-high').text(data.stats.high);
            $('#day-low').text(data.stats.low);
            $('#day-open').text(data.stats.open);
        }
    });
}

function loadPortfolio() {
    showLoading('optimization-results');
    showLoading('efficient-frontier');
    
    $.get('/api/portfolio_optimization', function(data) {
        if (data.success) {
            Plotly.newPlot('optimization-results', JSON.parse(data.chart).data,
                          JSON.parse(data.chart).layout);
            
            $('#expected-return').text(data.expected_return);
            $('#expected-risk').text(data.expected_volatility);
            $('#sharpe-ratio').text(data.sharpe_ratio);
            
            let weightsHtml = '<table class="table table-dark"><tr><th>Stock</th><th>Weight</th></tr>';
            for (const [stock, weight] of Object.entries(data.weights)) {
                weightsHtml += `<tr><td>${stock}</td><td>${weight}</td></tr>`;
            }
            weightsHtml += '</table>';
            $('#weights-table').html(weightsHtml);
        }
    });
}

function loadMonitor() {
    updateAlertsList();
    socket.emit('request_realtime');
}

function updateAlertsList() {
    $.get('/api/alerts', function(data) {
        if (data.success) {
            let alertsHtml = '';
            data.alerts.forEach(alert => {
                alertsHtml += `
                    <div class="alert-item mb-2 p-2 border-bottom">
                        <span class="alert-badge ${alert.type}">${alert.type}</span>
                        <strong>${alert.symbol}</strong>: ${alert.message}
                        <small class="text-muted float-end">${alert.timestamp}</small>
                    </div>
                `;
            });
            
            if (alertsHtml) {
                $('#alerts-list').html(alertsHtml);
            } else {
                $('#alerts-list').html('<p class="text-muted">No recent alerts</p>');
            }
        }
    });
}

function loadMLInsights() {
    const symbol = currentSymbol;
    
    showLoading('ml-chart');
    showLoading('ml-metrics');
    
    $.get(`/api/ml_predict/${symbol}`, function(data) {
        if (data.success) {
            Plotly.newPlot('ml-chart', JSON.parse(data.chart).data,
                          JSON.parse(data.chart).layout);
            
            let metricsHtml = '<table class="table table-dark"><tr><th>Model</th><th>RMSE</th><th>R²</th></tr>';
            for (const [model, metrics] of Object.entries(data.metrics)) {
                metricsHtml += `<tr>
                    <td>${model}</td>
                    <td>${metrics.rmse}</td>
                    <td>${metrics.r2}</td>
                </tr>`;
            }
            metricsHtml += '</table>';
            $('#ml-metrics').html(metricsHtml);
        }
    });
}

// Initialize on page load
$(document).ready(function() {
    console.log('Dashboard.js loaded');
    refreshCurrentView();
    
    if (updateInterval) clearInterval(updateInterval);
    updateInterval = setInterval(refreshCurrentView, 30000);
    
    $('#symbol-selector').change(function() {
        currentSymbol = $(this).val();
        refreshCurrentView();
    });
});

$(window).on('unload', function() {
    if (updateInterval) clearInterval(updateInterval);
    socket.disconnect();
});